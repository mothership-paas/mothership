require "sinatra"
require "sinatra/reloader" if development?
require "sinatra/content_for"
require "tilt/erubis"

configure do
  enable :sessions
  set :session_secret, 'secret'
end

configure do
  set :erb, :escape_html => true
end

def load_list_or_redirect_on_error(index)
  list = session[:lists].find { |list| list[:id] == index }
  return list if list
  session[:error] = "The specified list was not found."
  redirect "/lists"
end

def next_id(objects_with_id)
  # If there are no objects in the collection
  return 1 if objects_with_id.empty?

  max = objects_with_id.map { |object| object[:id] }.max
  max + 1
end

# Set session success or erro message depending on whether name is
# valid or not.
def set_session_success_or_error(name, success_msg)
  if !(1..100).cover? name.size
    session[:error] = "List name must be between 1 and 100 characters."
  elsif session[:lists].any? { |list| list[:name] == name }
    session[:error] = "List names must be unique."
  else
    session[:success] = success_msg
  end
end

helpers do
  def list_complete?(list)
    todos = list[:todos]  
    !todos.empty? && todos.all? { |todo| todo[:completed] == true }
  end

  def todo_list_status(list)
    todos = list[:todos]

    if !todos.empty? && todos.all? { |todo| todo[:completed] == true }
      'complete'
    else
      nil
    end
  end

  def number_incomplete(list)
    list[:todos].count { |todo| todo[:completed] == false }
  end

  def sort_lists(lists, &block)
    complete_lists = []

    lists.each_with_index do |list|
      list_complete?(list) ? complete_lists << list : yield(list)
    end

    complete_lists.each(&block) 
  end

  def sort_todos(todos, &block)
    complete_todos = []

    todos.each_with_index do |todo|
      todo[:completed] ? complete_todos << todo : yield(todo)
    end

    complete_todos.each(&block) 
  end
end

before do
  session[:lists] ||= []
  @lists = session[:lists]
end

before "/lists/:list_id/?*" do
  # Because /lists/new matches this route pattern
  return if params[:list_id] == 'new'

  @list_id = params[:list_id].to_i
  @list = load_list_or_redirect_on_error(@list_id)
  @todos = @list[:todos]
end

before "/lists/:list_id/todos/:todo_id/*" do
  @list_id = params[:list_id].to_i
  @todo_id = params[:todo_id].to_i
  @list = load_list_or_redirect_on_error(@list_id)
  @todos = @list[:todos]
  @todo = @todos.find { |todo| todo[:id] == @todo_id }
end

get "/" do
  redirect '/lists'
end

# View all lists
get "/lists" do
  erb :lists
end

# Render new lists form
get "/lists/new" do
  erb :new_list
end

# Create new list
post '/lists' do
  list_name = params[:list_name].strip
  success_msg = "The list was created."
  set_session_success_or_error(list_name, success_msg)

  if session[:success]
    session[:lists] << {
      id: next_id(session[:lists]),
      name: params[:list_name],
      todos: []
    }

    redirect('/lists') 
  else
    erb(:new_list)
  end
end

# View a single list
get '/lists/:list_id' do
  erb :single_list
end

# Render edit list form 
get '/lists/:list_id/edit' do
  erb :edit_list
end

# Edit the list
post '/lists/:list_id' do
  success_msg = "The list name has been updated."

  new_name = params[:list_name].strip
  set_session_success_or_error(new_name, success_msg)

  if session[:success]
    @list[:name] = new_name
    erb :single_list
  else
    erb :edit_list
  end
end

# Delete the list
post '/lists/:list_id/delete' do
  @lists.delete_if { |list| list[:id] == @list_id }

  if env["HTTP_X_REQUESTED_WITH"] == "XMLHttpRequest"
    "/lists"
  else
    session[:success] = "The list was deleted"
    redirect '/lists'
  end
end

# Create new todo
post '/lists/:list_id/todos' do
  todo = params[:todo].strip

  success_msg = "The todo has been added."
  set_session_success_or_error(todo, success_msg)

  if session[:success]
    todo_id = next_id(@list[:todos])
    @list[:todos] << {id: todo_id, name: todo, completed: false}
    redirect "/lists/#{@list_id}"
  else
    erb :single_list
  end
end

# Toggle todo item's complete status
post '/lists/:list_id/todos/:todo_id/toggle' do
  completed_status = params[:completed] == 'true' ? true : false
  @todo[:completed] = completed_status

  redirect "/lists/#{@list_id}"
end

# Delete a todo item
post '/lists/:list_id/todos/:todo_id/delete' do
  @todos.delete_if { |todo| todo[:id] == @todo_id }

  if env["HTTP_X_REQUESTED_WITH"] == "XMLHttpRequest"
    status 204
  else
    session[:success] = "The todo has been deleted."
    redirect "/lists/#{@list_id}"
  end
end

# Mark all todos complete
post '/lists/:list_id/complete-all' do
  if @todos.empty?
    session[:error] = "This list doesn't have any todos yet."
  else
    @todos.each { |todo| todo[:completed] = true }
    session[:success] = "All todos in this list have been marked complete"
  end

  redirect "/lists/#{@list_id}"
end
